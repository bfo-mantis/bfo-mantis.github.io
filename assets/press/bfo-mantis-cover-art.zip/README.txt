Cover art for releases by bfo.mantis.
Artwork (c) 2026 bfo.mantis Records. All rights reserved.
Provided for press and editorial use in connection with bfo.mantis releases.
