bfo.mantis wordmark

Set in Syne ExtraBold (SIL Open Font License), outlined, so no font is needed.
for-dark-backgrounds: light lettering with the lime dot.
for-light-backgrounds: dark lettering.
PNG files are 2400px wide with a transparent background.

(c) 2026 bfo.mantis Records. Provided for press and editorial use in connection with bfo.mantis.
